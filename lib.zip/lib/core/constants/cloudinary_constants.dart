class CloudinaryConstants {
  CloudinaryConstants._();

  static const String cloudName = 'dg20a7eey';
  static const String uploadPreset = 'campus_hub';
}
